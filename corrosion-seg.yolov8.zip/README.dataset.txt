# corrosion-seg > corrosion-seg-osfdk
https://universe.roboflow.com/sarthak-k/corrosion-seg-osfdk

Provided by a Roboflow user
License: CC BY 4.0

